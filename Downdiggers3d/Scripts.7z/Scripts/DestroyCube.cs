﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyCube : MonoBehaviour {
    public GameObject remains;

    void Update()
    {
        if (GameObject.Find("RigidBodyFPSController").GetComponent<Mine>().hit.collider != false)
        {
            if (GameObject.Find("RigidBodyFPSController").GetComponent<Mine>().mining == true && GameObject.Find("RigidBodyFPSController").GetComponent<Mine>().hit.collider.gameObject == this.gameObject)
            {
                Destroy(gameObject);
                Instantiate(remains, transform.position, transform.rotation);
            }
        }
    }
}
