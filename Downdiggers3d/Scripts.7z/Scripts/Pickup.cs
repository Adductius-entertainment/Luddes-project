﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour {

    public GameObject pickupObj;
    private RaycastHit hit;
    private bool pickedup = false;
	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.E) && pickedup == false)
        {
            if (Physics.Raycast(this.GetComponentInChildren<Camera>().ScreenPointToRay(Input.mousePosition), out hit, 10f))
            {
                if (hit.collider.tag == "Pickupable")
                {
                    pickedup = true;
                    pickupObj = hit.collider.transform.gameObject;
                    pickupObj.transform.parent = Camera.main.transform;
                    pickupObj.GetComponent<MeshCollider>().enabled = false;
                    pickupObj.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1f;
                    pickupObj.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePosition;
                }
            }
        }
        if(Input.GetMouseButtonDown(0) && pickedup == true) 
        {
            pickupObj.transform.parent = null;
            pickupObj.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
            pickupObj.GetComponent<MeshCollider>().enabled = true;
            pickupObj.GetComponent<Rigidbody>().AddForce(Camera.main.transform.forward * 500f, ForceMode.Impulse);
            pickedup = false;
        }
        if (Input.GetMouseButtonDown(1) && pickedup == true)
        {
            pickupObj.transform.parent = null;
            pickupObj.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
            pickupObj.GetComponent<MeshCollider>().enabled = true;
            pickedup = false;
        }
    }
}
