﻿using System.Collections;
using UnityEngine;

public class Mine : MonoBehaviour {

    public bool mining = false;
    public RaycastHit hit;
    private bool miningstart = false;

    // Update is called once per frame
    void Update () {
        if (Physics.Raycast(this.GetComponentInChildren<Camera>().ScreenPointToRay(Input.mousePosition), out hit, 5f))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * hit.distance, Color.yellow);
            if (Input.GetMouseButton(0))
            {
                miningstart = true;
                StartCoroutine(MineWait());
            }
            else
            {
                miningstart = false;
            }
        }
	}

    IEnumerator MineWait()
    {
        yield return new WaitForSeconds(1.0f);
        if (miningstart == true)
            {
            yield return new WaitForSeconds(2.0f);
            mining = true;
            yield return new WaitForSeconds(0.01f);
            mining = false;
            miningstart = false;
        }

    }
}
